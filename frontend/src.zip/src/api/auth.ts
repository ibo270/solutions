import { api } from './client'
export { bootstrapTokensFromStorage } from './client'

// Логин. Популярные варианты эндпоинтов — подставь свой первым.
const LOGIN_CANDIDATES = ['/api/auth/jwt/create/', '/api/auth/login/']

export async function login(email: string, password: string) {
  const payload = { email, password }
  for (const url of LOGIN_CANDIDATES) {
    try {
      const { data } = await api.post(url, payload)
      const access = data?.access ?? data?.token ?? data?.access_token
      const refresh = data?.refresh ?? data?.refresh_token ?? null
      if (access) return { access, refresh }
    } catch { /* try next */ }
  }
  throw new Error('Не удалось выполнить вход')
}

// опционально:
export async function logout() { /* серверный logout если есть */ }
