import { api } from './client'

export type Role = 'ADMIN' | 'COMPANY_MANAGER' | 'MANAGER' | 'USER'
export type Me = {
  id: number
  username?: string
  email?: string
  first_name?: string
  last_name?: string
  role?: Role
  is_staff?: boolean
  is_superuser?: boolean
}

const CANDIDATES = ['/api/auth/me/', '/api/users/me/', '/api/account/me/']

export async function me(): Promise<Me | null> {
  for (const url of CANDIDATES) {
    try {
      const { data } = await api.get(url)
      if (data && (data.id || data.email || data.username)) return data as Me
    } catch { /* try next */ }
  }
  return null
}
