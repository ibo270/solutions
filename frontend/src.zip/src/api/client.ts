import axios, {
  AxiosError,
  AxiosResponse,
  InternalAxiosRequestConfig,
  type AxiosRequestHeaders,
} from "axios";

const API_BASE = (import.meta.env.VITE_API_URL?.toString().replace(/\/$/, "")) || "";

export const api = axios.create({
  baseURL: API_BASE,
  withCredentials: false,
  headers: { Accept: "application/json", "Content-Type": "application/json" },
});

const raw = axios.create({
  baseURL: API_BASE,
  withCredentials: false,
  headers: { Accept: "application/json", "Content-Type": "application/json" },
});

let access: string | null = null;
let refresh: string | null = null;

export function setTokens(a: string | null, r: string | null) {
  access = a; refresh = r;
  if (a) localStorage.setItem("aa_access", a); else localStorage.removeItem("aa_access");
  if (r) localStorage.setItem("aa_refresh", r); else localStorage.removeItem("aa_refresh");
}
export function bootstrapTokensFromStorage() {
  access = localStorage.getItem("aa_access");
  refresh = localStorage.getItem("aa_refresh");
}

api.interceptors.request.use((cfg: InternalAxiosRequestConfig) => {
  if (access) {
    const headers: AxiosRequestHeaders = (cfg.headers ?? {}) as AxiosRequestHeaders;
    headers.Authorization = `Bearer ${access}`;
    cfg.headers = headers;
  }
  return cfg;
});

let refreshPromise: Promise<string> | null = null;
async function ensureAccessToken(): Promise<string> {
  if (!refresh) throw new Error("No refresh token");
  if (!refreshPromise) {
    refreshPromise = raw
      .post("/api/auth/jwt/refresh/", { refresh })
      .then((res) => {
        const newAccess = (res.data as any)?.access;
        if (!newAccess) throw new Error("No access from refresh");
        access = newAccess;
        localStorage.setItem("aa_access", newAccess);
        return newAccess;
      })
      .catch((e) => {
        setTokens(null, null);
        throw e;
      })
      .finally(() => { refreshPromise = null; });
  }
  return refreshPromise;
}

api.interceptors.response.use(
  (resp: AxiosResponse) => resp,
  async (error: AxiosError) => {
    const original = error.config as (InternalAxiosRequestConfig & { _retry?: boolean }) | undefined;
    const status = error.response?.status ?? 0;
    if (!original || original._retry || status !== 401 || !refresh) throw error;
    try {
      await ensureAccessToken();
      original._retry = true;
      const headers: AxiosRequestHeaders = (original.headers ?? {}) as AxiosRequestHeaders;
      if (access) headers.Authorization = `Bearer ${access}`;
      original.headers = headers;
      return api.request(original);
    } catch { throw error; }
  }
);

export default api;
