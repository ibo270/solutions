import api from "./client";

/** Мои билеты */
export async function getMyTickets() {
  const { data } = await api.get("/api/tickets/");
  return data as any[];
}

/** Купить билет */
export async function buyTicket(flight_id: number, seats = 1) {
  const { data } = await api.post("/api/tickets/", { flight_id, seats });
  return data;
}

/** Отменить билет */
export async function cancelTicket(id: number) {
  const { data } = await api.post(`/api/tickets/${id}/cancel/`);
  return data;
}
