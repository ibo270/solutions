import { useAuth } from "../store/AuthContext";

export default function ProfilePage() {
  const { user } = useAuth();
  if (!user) return null;
  return (
    <div className="p-4 text-white">
      <h1 className="text-2xl font-semibold mb-3">Профиль</h1>
      <div className="space-y-1 text-white/80">
        <div>Email: {user.email ?? "—"}</div>
        <div>Username: {user.username ?? "—"}</div>
        <div>Role: {user.role ?? "—"}</div>
      </div>
    </div>
  );
}
