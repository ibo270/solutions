import { useEffect, useState } from "react";
import { getMyTickets, cancelTicket } from "../api/tickets";
import { Card, Button } from "../components/UI";

export default function MyTickets(){
  const [tickets, setTickets] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  async function load(){
    setLoading(true);
    try { setTickets(await getMyTickets()); }
    finally { setLoading(false); }
  }
  useEffect(()=>{ load(); },[]);

  async function onCancel(id:number){
    await cancelTicket(id);
    await load();
  }

  return (
    <div className="space-y-3">
      {loading && <div className="text-slate-600 dark:text-white/70">Загрузка…</div>}
      {!loading && tickets.length===0 && <div className="text-slate-500 dark:text-white/60">Пока нет билетов</div>}
      {tickets.map(t=>(
        <Card key={t.id} className="p-4 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-500 dark:text-white/60">#{t.confirmation_id}</div>
            <div className="font-semibold">{t.flight.origin} → {t.flight.destination}</div>
            <div className="text-sm text-slate-600 dark:text-white/70">Статус: {t.status}</div>
          </div>
          <Button variant="outline" onClick={()=>onCancel(t.id)}>Отменить</Button>
        </Card>
      ))}
    </div>
  );
}
