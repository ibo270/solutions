import { useEffect, useState } from 'react'
import { fetchFlights, type Flight } from '../api/flights'

export default function SchedulePage() {
  const [flights, setFlights] = useState<Flight[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const run = async () => {
      try {
        setLoading(true)
        setError(null)
        const list = await fetchFlights()
        setFlights(list)
      } catch (e: any) {
        setError(e?.message || 'Ошибка загрузки расписания')
      } finally {
        setLoading(false)
      }
    }
    run()
  }, [])

  if (loading) return <div className="p-6 text-slate-200">Загружаем расписание…</div>
  if (error) return <div className="p-6 text-red-400">Ошибка: {error}</div>
  if (!flights.length) return <div className="p-6 text-slate-200">Расписание пусто</div>

  return (
    <div className="p-6 grid gap-3 md:grid-cols-2">
      {flights.map((f) => (
        <div key={f.id} className="bg-slate-800/60 rounded-xl p-4">
          <div className="text-sm opacity-80">
            {f.company_code ?? '—'} · {f.flight_no ?? f.id}
          </div>
          <div className="font-semibold">{f.origin} → {f.destination}</div>
          <div className="text-sm opacity-80">
            Вылет: {new Date(f.departure_at).toLocaleString()} • Прилет: {new Date(f.arrival_at).toLocaleString()}
          </div>
          {!!f.status && <div className="text-xs mt-1 opacity-70">Статус: {f.status}</div>}
        </div>
      ))}
    </div>
  )
}
