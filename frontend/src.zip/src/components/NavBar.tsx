import { Link, NavLink, useNavigate } from "react-router-dom";
import { useEffect, useMemo, useState } from "react";
import LoginModal from "./LoginModal";
import { Button } from "./UI";
import { me } from "../api/accounts";
import { logout } from "../api/auth";
import { bootstrapTokensFromStorage } from "../api/client";
import { useTheme } from "../store/ThemeContext"; // <= провайдер темы
// если нет lucide-react — можно убрать импорты и ниже оставить эмодзи
import { Sun, Moon } from "lucide-react";

type User = {
  id: number;
  username?: string;
  email?: string;
  first_name?: string;
  last_name?: string;
  role?: string;
  is_staff?: boolean;
  is_superuser?: boolean;
};

export default function NavBar() {
  const [showLogin, setShowLogin] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const nav = useNavigate();
  const { theme, toggle } = useTheme();

  useEffect(() => {
    bootstrapTokensFromStorage();
    (async () => {
      try {
        setLoading(true);
        const u = await me();
        setUser(u);
      } catch {
        setUser(null);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  function doLogout() {
    logout();
    setUser(null);
    nav("/");
  }

  const canAdmin = useMemo(
    () =>
      !!user &&
      (user.is_superuser ||
        user.is_staff ||
        (user.role ?? "").toUpperCase() === "ADMIN"),
    [user]
  );

  const canManager = useMemo(
    () =>
      !!user &&
      (canAdmin ||
        ["COMPANY_MANAGER", "MANAGER"].includes(
          (user.role ?? "").toUpperCase()
        )),
    [user, canAdmin]
  );

  const displayName =
    user?.username ||
    [user?.first_name, user?.last_name].filter(Boolean).join(" ") ||
    user?.email ||
    (user ? `user#${user.id}` : "");

  const linkClass = ({ isActive }: { isActive: boolean }) =>
    `px-3 py-1.5 rounded-lg ${isActive ? "bg-white/10" : "hover:bg-white/10"}`;

  return (
    <>
      <div className="sticky top-0 z-30 bg-slate-900/80 text-white backdrop-blur-sm border-b border-white/10">
        <div className="mx-auto max-w-6xl px-4 h-14 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="h-9 w-9 grid place-items-center rounded-2xl bg-gradient-to-tr from-blue-500 to-indigo-500 shadow">
              ✈️
            </div>
            <div className="leading-tight">
              <div className="font-semibold">Aurora Air</div>
              <div className="text-[10px] uppercase opacity-70">
                BEYOND COMFORT
              </div>
            </div>
          </Link>

          <div className="flex items-center gap-2">
            <NavLink to="/search" className={linkClass}>
              Поиск
            </NavLink>
            <NavLink to="/tickets" className={linkClass}>
              Мои билеты
            </NavLink>
            <NavLink to="/schedule" className={linkClass}>
              Расписания
            </NavLink>
            {canManager && (
              <NavLink to="/company" className={linkClass}>
                Компания
              </NavLink>
            )}
            {canAdmin && (
              <a
                href="/admin/"
                className="px-3 py-1.5 rounded-lg hover:bg-white/10"
                rel="noreferrer"
              >
                admin
              </a>
            )}

            {/* Переключатель темы */}
            <button
              aria-label="Toggle theme"
              onClick={toggle}
              className="ml-1 h-8 w-8 grid place-items-center rounded-lg hover:bg-white/10"
              title={theme === "dark" ? "Светлая тема" : "Тёмная тема"}
            >
              {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
              {/* если нет lucide-react, замени на:
                  {theme === "dark" ? "☀️" : "🌙"} */}
            </button>

            {loading ? (
              <span className="ml-2 text-sm text-white/70">Загрузка…</span>
            ) : !user ? (
              <Button className="ml-2" onClick={() => setShowLogin(true)}>
                Войти
              </Button>
            ) : (
              <div className="flex items-center gap-2 ml-2">
                <NavLink
                  to="/profile"
                  className="px-3 py-1.5 rounded-lg hover:bg-white/10"
                >
                  {displayName}
                </NavLink>
                <Button variant="ghost" onClick={doLogout}>
                  Выйти
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      {showLogin && (
        <LoginModal
          onClose={() => setShowLogin(false)}
          onSuccess={(u: User) => {
            setUser(u);
            setShowLogin(false);
          }}
        />
      )}
    </>
  );
}
