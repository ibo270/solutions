import { Button, Card } from "./UI";
import type { Flight } from "../api/flights";

type Props = {
  f: Flight;
  onBuy?: (id: number) => void;
};

export default function FlightCard({ f, onBuy }: Props) {
  const soldOut = (f.seats_available ?? 0) <= 0;

  const company = f.company_code ?? "—";
  const number = f.flight_no ?? f.id;

  const price =
    typeof f.base_price === "number"
      ? f.base_price.toLocaleString()
      : (f.base_price ?? "—");

  const depart = new Date(f.departure_at).toLocaleString();
  const arrive = new Date(f.arrival_at).toLocaleString();

  return (
    <Card className="p-4 hover:shadow-md transition">
      <div className="flex items-center justify-between gap-4">
        <div>
          <div className="text-sm text-slate-500 dark:text-white/60">
            {company} • {number}
          </div>
          <div className="font-semibold text-slate-900 dark:text-white">
            {f.origin}{" "}
            <span className="text-slate-400 dark:text-white/60">→</span>{" "}
            {f.destination}
          </div>
          <div className="text-sm text-slate-600 dark:text-white/70">
            {depart} — {arrive}
          </div>
          {f.status && (
            <div className="text-xs mt-1 text-slate-500 dark:text-white/60">
              Статус: {f.status}
            </div>
          )}
        </div>

        <div className="text-right">
          <div className="text-lg font-semibold text-slate-900 dark:text-white">
            {price}
          </div>
          <div className="text-xs text-slate-500 dark:text-white/60">
            {soldOut ? "Нет мест" : `${f.seats_available ?? 0} мест`}
          </div>
          <Button
            className="mt-2 w-full"
            disabled={soldOut || !onBuy}
            onClick={() => onBuy?.(f.id)}
          >
            Купить
          </Button>
        </div>
      </div>
    </Card>
  );
}
